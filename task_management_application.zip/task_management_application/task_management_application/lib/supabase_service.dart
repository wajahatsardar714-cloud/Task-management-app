import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static const String _supabaseUrl = 'https://bvfelipivdvroqlmvtbj.supabase.co';
  static const String _supabaseKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ2ZmVsaXBpdmR2cm9xbG12dGJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcyODgyNTksImV4cCI6MjA2Mjg2NDI1OX0.FZkfTsbGWJ3Qyssc0d-tj-b7xC8JeHf54fJsYM4OGgM';

  final SupabaseClient _client = Supabase.instance.client;

  Future<void> initialize() async {
    try {
      await Supabase.initialize(url: _supabaseUrl, anonKey: _supabaseKey);
    } catch (e) {
      throw Exception('Failed to initialize Supabase: $e');
    }
  }

  // Insert a new task
  Future<void> insertTask({
    required String title,
    String? description,
    DateTime? dueDate,
    required String status,
  }) async {
    try {
      final response = await _client.from('tasks').insert({
        'title': title,
        'description': description,
        'due_date': dueDate?.toIso8601String(),
        'status': status,
      }).execute();

      if (response.error != null) {
        throw Exception('Failed to insert task: ${response.error!.message}');
      }
    } catch (e) {
      throw Exception('Failed to insert task: $e');
    }
  }

  // Fetch all tasks
  Future<List<Task>> fetchAllTasks() async {
    try {
      final response = await _client.from('tasks').select().order('created_at');
      return List<Map<String, dynamic>>.from(response)
          .map((data) => Task.fromMap(data))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch tasks: $e');
    }
  }

  // Fetch tasks by status
  Future<List<Task>> fetchTasksByStatus(String status) async {
    try {
      final response = await _client
          .from('tasks')
          .select()
          .eq('status', status)
          .order('created_at');
      return List<Map<String, dynamic>>.from(response)
          .map((data) => Task.fromMap(data))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch tasks by status: $e');
    }
  }

  // Update a task
  Future<void> updateTask({
    required int id,
    String? title,
    String? description,
    DateTime? dueDate,
    String? status,
  }) async {
    final updates = <String, dynamic>{};
    if (title != null && title.isNotEmpty) updates['title'] = title;
    if (description != null && description.isNotEmpty)
      updates['description'] = description;
    if (dueDate != null) updates['due_date'] = dueDate.toIso8601String();
    if (status != null && status.isNotEmpty) updates['status'] = status;

    try {
      await _client.from('tasks').update(updates).eq('id', id);
    } catch (e) {
      throw Exception('Failed to update task: $e');
    }
  }

  // Delete a task
  Future<void> deleteTask(int id) async {
    try {
      await _client.from('tasks').delete().eq('id', id);
    } catch (e) {
      throw Exception('Failed to delete task: $e');
    }
  }
}

// Task model for type safety
class Task {
  final int id;
  final String title;
  final String? description;
  final DateTime? dueDate;
  final String status;
  final DateTime createdAt;

  Task({
    required this.id,
    required this.title,
    this.description,
    this.dueDate,
    required this.status,
    required this.createdAt,
  });

  factory Task.fromMap(Map<String, dynamic> map) {
    return Task(
      id: map['id'] as int,
      title: map['title'] as String,
      description: map['description'] as String?,
      dueDate: map['due_date'] != null
          ? DateTime.parse(map['due_date'] as String)
          : null,
      status: map['status'] as String,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
