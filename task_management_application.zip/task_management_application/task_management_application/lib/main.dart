import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://bvfelipivdvroqlmvtbj.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ2ZmVsaXBpdmR2cm9xbG12dGJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcyODgyNTksImV4cCI6MjA2Mjg2NDI1OX0.FZkfTsbGWJ3Qyssc0d-tj-b7xC8JeHf54fJsYM4OGgM',
  );
  runApp(TaskApp());
}

class TaskApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Supabase Task Manager',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: TaskHome(),
    );
  }
}

class TaskHome extends StatefulWidget {
  @override
  _TaskHomeState createState() => _TaskHomeState();
}

class _TaskHomeState extends State<TaskHome> {
  final SupabaseClient client = Supabase.instance.client;
  List tasks = [];

  final titleCtrl = TextEditingController();
  final descCtrl = TextEditingController();
  final dateCtrl = TextEditingController();
  String selectedStatus = 'pending';

  @override
  void initState() {
    super.initState();
    fetchTasks();
  }

  Future<void> insertTask() async {
    final response = await client.from('tasks').insert({
      'title': titleCtrl.text,
      'description': descCtrl.text,
      'due_date': dateCtrl.text,
      'status': selectedStatus,
    });
    fetchTasks();
    clearForm();
  }

  Future<void> fetchTasks() async {
    final response =
        await client.from('tasks').select().order('due_date', ascending: true);
    setState(() {
      tasks = response;
    });
  }

  Future<void> updateTask(String id) async {
    await client.from('tasks').update({
      'title': titleCtrl.text,
      'description': descCtrl.text,
      'due_date': dateCtrl.text,
      'status': selectedStatus,
    }).eq('id', id);
    fetchTasks();
    clearForm();
  }

  Future<void> deleteTask(String id) async {
    await client.from('tasks').delete().eq('id', id);
    fetchTasks();
  }

  void clearForm() {
    titleCtrl.clear();
    descCtrl.clear();
    dateCtrl.clear();
    selectedStatus = 'pending';
  }

  void fillForm(Map task) {
    titleCtrl.text = task['title'];
    descCtrl.text = task['description'] ?? '';
    dateCtrl.text = task['due_date']?.toString() ?? '';
    selectedStatus = task['status'] ?? 'pending';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Task Manager with Supabase")),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
                controller: titleCtrl,
                decoration: InputDecoration(labelText: 'Title')),
            TextField(
                controller: descCtrl,
                decoration: InputDecoration(labelText: 'Description')),
            TextField(
              controller: dateCtrl,
              decoration: InputDecoration(labelText: 'Due Date (yyyy-MM-dd)'),
              onTap: () async {
                DateTime? date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2022),
                  lastDate: DateTime(2100),
                );
                if (date != null) {
                  dateCtrl.text = DateFormat('yyyy-MM-dd').format(date);
                }
              },
              readOnly: true,
            ),
            DropdownButton<String>(
              value: selectedStatus,
              onChanged: (val) => setState(() => selectedStatus = val!),
              items: ['pending', 'completed']
                  .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                  .toList(),
            ),
            ElevatedButton(onPressed: insertTask, child: Text('Add Task')),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (_, index) {
                  final task = tasks[index];
                  return ListTile(
                    title: Text(task['title']),
                    subtitle: Text(
                        'Status: ${task['status']} | Due: ${task['due_date']?.split("T").first ?? ""}'),
                    trailing: Wrap(
                      spacing: 10,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit, color: Colors.orange),
                          onPressed: () {
                            fillForm(task);
                            updateTask(task['id']);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteTask(task['id']),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
